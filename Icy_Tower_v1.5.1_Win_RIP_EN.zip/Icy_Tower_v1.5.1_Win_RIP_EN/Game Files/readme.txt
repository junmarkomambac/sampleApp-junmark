


                            Free Lunch Design

                                presents

                           Harold the Homeboy

                                   in

            ####  ###  ## ##    ######  ###  ##   ## ##### ####   (R)
             @@  @@ @@ @@ @@      @@   @@ @@ @@   @@ @@    @@ @@
             %%  %%     %%%%      %%   %% %% %% % %% %%%   %%%%
             ::  :: ::    ::      ::   :: :: ::: ::: ::    :: ::
            ''''  '''   '''       ''    '''  ''   '' ''''' '' ''

                      I   C   Y      T    O    W   E   R  
                                                                   v1.5.1
    =====================================================================


GENERAL

    Welcome to Icy Tower(R)! This game is completely free. You may play
    it as much as you like without paying a single buck. In exchange
    for playing it, you are instead asked for a small favour. Please 
    let all your friends know about the game. We're sure they will 
    love it. Also, feel free to send us any comments you might have 
    about this game. See contact & support at the end of this document.


DISTRIBUTION

    Icy Tower is freeware, anybody may (and should) play it. Therefore,
    you are encouraged to distribute this game (in its original form)
    like crazy. Upload it to every web site and BBS you know, give a copy to
    all your friends, etc. There are however a few requirements:
    
      * Give proper credit to Free Lunch Design
      * Provide a link back to our site www.freelunchdesign.com
      * You are not allowed to repackage the game. The installation file
        as it can be found on www.freelunchdesign.com must be kept intact.
      * The game may only be downloaded in it's original form. It may not be 
        served to users via download managers, wrapped with toolbars, or 
        anything similar.
        

    Also, this game may not be included in a compilation or any other
    kind of commercial package without permission from the authors.
    This includes cover disks, game compilations and everything else that 
    involves money. See contact near the end of this document.


DISCLAIMER

    Free Lunch Design does not accept responsibility for any effects,
    adverse or otherwise, that this software may have on you, your
    computer, your sanity, your dog, or anything else that you can think
    of. Use it at your own risk. We have, however, never experienced any
    trouble with it.


DESCRIPTION

    Icy Tower is small and short but surprisingly addictive game. Control
    Harold the Homeboy as he climbs his tower of infinite height whilst
    doing cool jumps and moves in order to get a high score and awe from
    his friends in the hood.


INSTALLING AND STARTING THE GAME

    Since you're reading this text the game is probably installed and ready
    to be played already. If not, locate the installation program
    (icytower_install.exe) and run it. When installed you will find the
    necessary shortcuts in the start menu.


THE STORY

    One day, when Harold had nothing in particular to do, he found a huge
    tower. The tower was icy cold, incredibly high and totally deserted.
    "Ey, dis seems like a cool place to hang out in", Harold thought and
    entered.

    The tower was indeed empty, but small platforms here and there made it
    possible for anyone brave enough to ascend to its higher levels.
    "Ey, I bet a homie like me can do some mighty cool jumps and moves in
    here", thought Harold, gazing upwards.

    And so it started... Help Harold to make the coolest and highest jumps
    in history!


THE TITLE SCREEN

    The title screen will present you with a menu of the following format:

    PLAY GAME       - Starts a new game. You can either play a classic game,
                      or you can make it easier or harder by customizing the 
                      tower and then starting a custom game
    INSTRUCTIONS    - Shows you a brief instruction screen
    PROFILE         - View your profile or start a new one
    HIGH SCORES     - View all the high scores made in the game
    LOAD REPLAY	    - Loads and plays saved replays
    OPTIONS         - Lets you change sound and graphics settings
    EXIT            - Exits to your OS

    Use the arrow keys or game pad to navigate the menu. The current selection
    will be pointed at by Harold's hand. Use space or button 1 to select.


PROFILES

    Icy Tower will track your performance over time in a profile. As you play
    and get better, you will also rise in rank. All the details and the data 
    collected in your profile can be viewed in the profile menu.
    
    If many players are sharing the same installation, multiple profiles are
    a great way of separating each others' achievements.


THE OPTIONS MENU

    The options menu is divided into four smaller menus. They are all
    described here:


    GFX OPTIONS

    The graphical options control the visuals of the game. Here you 
    can alter settings that control the character and floors.
    To add custom characters, see that section below. New start floors
    must be unlocked by jumping higher and higher in the tower.

    	CHARACTER       - Select what character to play with
    	START FLOOR     - Select what floor type to start on
    	EYE CANDY       - Increase or decrease amount of graphical objects
    	FULLSCREEN      - Toggle between fullscreen and windowed mode


    SOUND OPTIONS

    Here you can change the audio output.

    	SOUND VOL       - Adjust sfx output
        MUSIC VOL       - Adjust music output


    CONTROLS

    In the control menu you can customize the keys used for the game.

	    LEFT            - Select key for left
	    RIGHT           - Select key for right
	    JUMP            - Select key for jump
	    REJUMP          - Toggle rejump on and off (see Note 2 below)


    Note 1: Eye Candy does not add to the game play but will improve the
            playing experience. If your computer is slow and the
            game lags you can try to turn this off to improve performance.

    Note 2: Rejump. If this is on, you can hold spacebar and Harold will
            jump constantly. If off you'll have to repress space to make
            a new jump. Some like it one way, some like it the other.


GENERAL CONTROLS

    Move about in the menus using the arrow keys and enter. When playing,
    these are the default keys for controlling Harold:

        Left and right arrows     - Run left/right
        Space                     - Jump
        P                         - Pause

    You can quit the game back to the menu by pressing P and then ESC.

    If you have a game pad connected, use the direction pad to move Harold
    and button 1 to jump.


PLAYING

    The first thing you need to know is that Harold will constantly
    accelerate as long as you move him. The second thing is that the faster
    Harold runs, the higher and longer will he jump. The third thing is
    that you can bump into walls, turn around and maintain most of your
    speed. This is a useful technique if you want to do cool jumps.

    As you ascend the tower it will start to scroll slowly and you will
    have to keep up in order to not fall of the screen. This is not so
    hard in the beginning since the scrolling is very slow. But every 30
    seconds, an alarm clock will sound and the scrolling will go slightly
    faster. The clock in the upper left corner of the screen shows you how
    much time you have left until the next speedup.

    Icy Tower can be played in many ways, although you might not get a
	very high score in some of them. :) The main goal of the game is to get
    a high score and a nice place in the high score list.

    You will get 10 points for each floor you reach. This alone will not
    give you any great scores, however. To be really victorious, you need
    to learn the secrets of combo jumps.

    To start the combo mode, you will have to make a jump at least two
    floors high; i.e., run with Harold until you have enough speed, jump, and
    land two floors above where you started.

    When in combo mode the meter to the left of the screen will fill up but
    will drain within one second. In order to stay in combo mode you need
    to make another jump of at least two floors. If you manage to do that
    before the meter is empty, the meter will be refilled and you can
    continue doing combo jumps.

    When the meter runs out or if you make a non-combo jump, you have
    finished your combo and you will be given score depending on how many
    floors in total you managed to climb during your combo.

    The rewards you can be given are: GOOD, SWEET, GREAT, WOW, AMAZING and
    EXTREME, and a few more. The latter ones are really hard to get and will
    require a lot of practice.

    The tower is infinitely high and Harold will never reach the top.
    It's up to you to make sure that his stay in the tower generates a lot
    of score so that he doesn't need to feel ashamed in front of his
    friends. Good luck!


REPLAYS

    Icy Tower features the possibility save your jump sessions and
    view them at a later time. You can also send the replays to your friends
    and brag about how skilled you are. Every time you finish a jump session,
    a menu will appear where you can either watch it all again, save it or
    continue to the main menu.

    If you choose to save the replay, you need to enter your name (so that
    you can take credit) and a filename. You can also enter a comment to 
    remember this special occasion. How far you got, your score etc.
    will be recorded automatically. The replays will be saved in your profile's
    replays/ directory where you installed Icy Tower. If you want to send
    your replay to a friend, this is the place to look for it.

    To view a replay at a later stage, either open it via the LOAD REPLAY
    option in the main menu, or simply drag and drop the file on the Icy
    Tower icon.


CUSTOM CHARACTERS

    In Icy Tower you can make your own characters, complete with their
    own sound effects and background music. It's not altogether easy, but
    if you set your mind to it, you will succeed. For information on how
    to make your own characters or add someone else's, read the information
    available in the characters/ directory.


TROUBLESHOOTING / FAQ

    Before trying anything out, make sure you have the latest drivers for
    DirectX and for your graphics and sound cards!

    Q: The gamepad/joystick acts strange. It seems to pull in the wrong
       direction and so on. What is wrong?
    A: During setup your gamepad/joystick will be initialized and calibrated.
       Don't touch it! Let it be still while the game is in setup-mode.

    Q: The game starts and the menu shows but I cannot choose anything!
    A: Disconnect any joysticks and gamepads.

    Q: The game runs slow and choppy! How can I speed it up?
    A: Try turning off the Eye Candy and try turning on or off fullscreen.

    Q: I never manage to get any cool combo jumps! What am I doing wrong?
    A: Try harder. :) Make sure you use the walls to bump on and take
       it slow, you have more time to concentrate than what it feels like.


SPECIAL THANKS

    A game won't get made all by itself. There's always people and stuff
    around who inspires the final product. In the case of Icy Tower 1.5 
    we'd like to thank everybody who ever played the game. Without you
    guys we wouldn't have the inspiration to go on.

    A truck load of thanks goes out to the forum members at the Free
    Lunch Design forum for helping out, testing and finding bugs 
    everytime there is a new release. Without you there would be no new 
    version.

    Also, all of you who play the game and compete with your friends,
    spreading the game all over the world. Thank you too! 


TECHNICAL MUMBO JUMBO

  Icy Tower is written in c using the game library Allegro. For
  sound effect playback, LOGG was used. For PNG handling, the
  libpng and zlib libraries were used. The threading library
  pthreads was also used.

    Allegro & Logg: http://alleg.sf.net
    zlib:           http://www.zlib.net
    libpng:         http://libpng.sourceforge.net/index.html


AUTHORS & CONTACT

    Free Lunch Design is a gaming brand from Sweden. Our aim is to 
    create small, high quality games, where game play is in focus.

    Icy Tower was designed by Johan Peitz who also wrote the code for
    the game. The delicious pixel graphics were made by Emanuel Garnheim. 
    Sound effects and music created by SomaTone Interactive Audio.

    Visit us on the web:	http://www.freelunchdesign.com

    If you have comments, bug reports, or just want to ask something
    you can contact Free Lunch Design by e-mail. We do however get a
    lot of mail and it might take a while before we answer, so if you
    have a question please check the online FAQs and forums first.

	E-Mail: info (at) freelunchdesign (dot) com


FINAL WORDS

    Icy Tower became a game much bigger than we ever could have imagined.
    It is played and enjoyed by millions of gamers, of all ages, all over 
    the world. It's nice to see that all the players of Icy Tower out there, 
    are having as much fun as we had when we created the game.

    In closing, here's a poem by John Boney:

        "Harold

	As I sat  there,  trying to complete  my work,  he was calling me.
	When I  was in the hall  gathering  books,  I heard his voice.  My
	heart pumps more blood  through my restless body,  and he is still
	there, constantly beckoning me.  I have said to him that he cannot
	control  my life,  but his power  overrules my futile pleas.  I am
	a dog on a leash, the cruel master  constantly  jerking me back to
	him. When we first met, he only spoke in unintelligible ramblings.
	"Whoop-a-doobadoo!"  he would say.  My friend why do you speak so?
	I see  you  for  hours  everyday, yet  I  cannot  understand  you.
	"Whoop-a-doobadoo! Whoop-a-doobadoo!"  The more I listen, the more
	I hear.  "Come,"  he now says,  "I want to be with you."  I try to
	sleep,  but he jerks me back  from my rest on this  cold floor. If
	only I  could remove  this painful  collar, which  engrafts itself
	around  my neck and  controls my  head.  Oh,  how it itches.  I am
	powerless  before the master.  His eyes are covered  to shield him
	from the pain  he is causing. He is unaware  that he is abusing me
	every moment he lives.  "Join me. You are safe in here." Ouch, why
	must you  jerk me so?  Your kazoo is  harmonious,   but it plays a
	tune of death. Are you trying to torture me?  If only you knew the
	strife  you  inflict,  you  could  change  your  ways.  You wear a
	toboggan,  for  it  is  cold  within  these  walls.  But I have no
	protection,  except this collar,  which I fear may never come off."






                                - The End-


